require './lib/controller.rb'

Controller.new.run_game
